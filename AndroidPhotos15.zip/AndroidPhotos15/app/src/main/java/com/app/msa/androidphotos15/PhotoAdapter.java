package com.app.msa.androidphotos15;

import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import model.Photo;

/**
 * Created by shahe on 11/28/2017.
 */

public class PhotoAdapter extends RecyclerView.Adapter<PhotoAdapter.ViewHolder> {

    ArrayList<Photo> photoArrayList;
    Context context;
    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView photoImageView;
        ImageButton deleteButton;
        public ViewHolder(Context context,View view)
        {
            super(view);
            photoImageView = view.findViewById(R.id.photo_ImageView);
            deleteButton = view.findViewById(R.id.photo_deleteButton);
        }
    }

    public PhotoAdapter(ArrayList<Photo> l, Context c){
        photoArrayList=l;
        context=c;
    }
    public Context getContext(){
        return context;
    }
    @Override
    public PhotoAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View photoView = inflater.inflate(R.layout.photo_viewholder,parent,false);
        ViewHolder viewHolder = new ViewHolder(context,photoView);
        return viewHolder;

    }
    @Override
    public void onBindViewHolder(PhotoAdapter.ViewHolder holder, int position) {
        ImageView photoImageView = holder.photoImageView;
        Photo p = photoArrayList.get(position);
        photoImageView.setScaleType(ImageView.ScaleType.FIT_XY);
        File imgFile = new File(p.getUrl());
        if(imgFile.exists()){
            ImageView myImage = new ImageView(context);
            photoImageView.setImageURI(Uri.fromFile(imgFile));
        }

        ImageButton deleteButton = holder.deleteButton;
        deleteButton.setOnClickListener( v->{
            //promots the user to confirm weather they really want to delete the photo and then calls the delete
            //photo method
            new AlertDialog.Builder(getContext()).setTitle("Confirm your Action")
                    .setMessage("Do you really want delete this photo?")
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            removeItems(position);
                        }})
                    .setNegativeButton(android.R.string.no, null).show();
        });
    }

    @Override
    public int getItemCount() {
        Log.e("Er",photoArrayList.size()+" ");
        return photoArrayList.size();
    }

    public void removeItems(int position){
        photoArrayList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, getItemCount() - position);
    }
}
